module.exports = {
  testMatch: ["<rootDir>/test/*.test.js"],
};
